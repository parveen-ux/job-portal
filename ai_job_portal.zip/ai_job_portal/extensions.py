"""
extensions.py
-------------
Some Flask extensions (like Bcrypt and LoginManager) need to be created
BEFORE the app exists but USED inside route files that are imported
AFTER the app exists. To avoid circular imports, we create them once
here, then call `.init_app(app)` on them inside app.py.
"""

from flask_bcrypt import Bcrypt
from flask_login import LoginManager

bcrypt = Bcrypt()
login_manager = LoginManager()
login_manager.login_view = "auth.login"  # redirects here if a non-logged-in user hits a @login_required page
