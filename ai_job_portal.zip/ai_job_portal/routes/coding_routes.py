"""
routes/coding_routes.py
--------------------------
Handles Coding Practice.
This MVP lists practice problems by topic/difficulty and shows sample
input/output for self-review. It intentionally does NOT execute
user-submitted code — running arbitrary code safely requires a
sandboxed execution service, which is a separate infrastructure
project (e.g. Docker-based judge) beyond this app's scope.
"""

from flask import Blueprint, render_template, request
from flask_login import login_required
from models.coding import CodingProblem

coding_bp = Blueprint("coding", __name__)


@coding_bp.route("/coding")
@login_required
def practice():
    topic = request.args.get("topic", "")
    difficulty = request.args.get("difficulty", "")

    query = CodingProblem.query
    if topic:
        query = query.filter(CodingProblem.topic == topic)
    if difficulty:
        query = query.filter(CodingProblem.difficulty == difficulty)

    problems = query.all()
    return render_template("coding/practice.html", problems=problems, topic=topic, difficulty=difficulty)


@coding_bp.route("/coding/<int:problem_id>")
@login_required
def problem_detail(problem_id):
    problem = CodingProblem.query.get_or_404(problem_id)
    return render_template("coding/detail.html", problem=problem)
