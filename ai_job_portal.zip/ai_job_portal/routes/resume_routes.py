"""
routes/resume_routes.py
-------------------------
Handles two related but separate features:
1. Resume Builder  -> user fills a form, we save it + generate a PDF
2. Resume Analyzer -> user pastes/uploads resume text, Gemini scores it
"""

from flask import Blueprint, render_template, request, send_file
from flask_login import login_required, current_user
from io import BytesIO
from xhtml2pdf import pisa
from models import db
from models.resume import Resume
from services.gemini_service import analyze_resume

resume_bp = Blueprint("resume", __name__)


# ---------- RESUME BUILDER ----------

@resume_bp.route("/resume/builder", methods=["GET", "POST"])
@login_required
def builder():
    if request.method == "POST":
        resume = Resume(
            user_id=current_user.id,
            full_name=request.form.get("full_name"),
            email=request.form.get("email"),
            phone=request.form.get("phone"),
            summary=request.form.get("summary"),
            education=request.form.get("education"),
            experience=request.form.get("experience"),
            skills=request.form.get("skills"),
            projects=request.form.get("projects"),
        )
        db.session.add(resume)
        db.session.commit()
        return render_template("resume/preview.html", resume=resume)

    return render_template("resume/builder.html")


@resume_bp.route("/resume/<int:resume_id>/download")
@login_required
def download_resume(resume_id):
    """Renders the resume as HTML, then converts that HTML to a PDF file for download."""
    resume = Resume.query.get_or_404(resume_id)
    html = render_template("resume/pdf_template.html", resume=resume)

    pdf_buffer = BytesIO()
    pisa.CreatePDF(html, dest=pdf_buffer)
    pdf_buffer.seek(0)

    return send_file(
        pdf_buffer,
        as_attachment=True,
        download_name=f"{resume.full_name or 'resume'}.pdf",
        mimetype="application/pdf",
    )


# ---------- RESUME ANALYZER ----------

@resume_bp.route("/resume/analyzer", methods=["GET", "POST"])
@login_required
def analyzer():
    analysis_result = None
    if request.method == "POST":
        resume_text = request.form.get("resume_text", "")
        target_job = request.form.get("target_job", "")

        try:
            analysis_result = analyze_resume(resume_text, target_job_title=target_job)
        except Exception as e:
            analysis_result = "Sorry, the analyzer is temporarily unavailable. Please try again."
            print(f"[Gemini error] {e}")

    return render_template("resume/analyzer.html", analysis_result=analysis_result)
