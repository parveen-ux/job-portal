"""
routes/dashboard_routes.py
-----------------------------
Handles:
- "/"          -> public landing page
- "/dashboard" -> logged-in user's profile dashboard (summary of activity)
"""

from flask import Blueprint, render_template
from flask_login import login_required, current_user
from models.resume import Resume
from models.chat import ChatMessage
from services.recommendation_service import recommend_jobs_for_user

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/")
def home():
    return render_template("index.html")


@dashboard_bp.route("/dashboard")
@login_required
def dashboard():
    resume_count = Resume.query.filter_by(user_id=current_user.id).count()
    chat_count = ChatMessage.query.filter_by(user_id=current_user.id, sender="user").count()
    top_matches = recommend_jobs_for_user(current_user, limit=3)

    return render_template(
        "dashboard.html",
        resume_count=resume_count,
        chat_count=chat_count,
        top_matches=top_matches,
    )
