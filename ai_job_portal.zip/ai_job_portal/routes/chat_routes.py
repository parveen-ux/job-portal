"""
routes/chat_routes.py
----------------------
Powers the AI Chatbot for career guidance.
- GET /chat        -> renders the chat UI, pre-loaded with past history
- POST /chat/send  -> receives one new message via fetch() from chat.js,
                       calls Gemini, saves both messages, and returns the
                       bot's reply as JSON (so the page doesn't reload)
"""

from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from models import db
from models.chat import ChatMessage
from services.gemini_service import get_chat_response

chat_bp = Blueprint("chat", __name__)


@chat_bp.route("/chat")
@login_required
def chat_page():
    # Load this user's previous messages so the conversation persists across visits
    history = (
        ChatMessage.query.filter_by(user_id=current_user.id)
        .order_by(ChatMessage.created_at.asc())
        .all()
    )
    return render_template("chat.html", history=history)


@chat_bp.route("/chat/send", methods=["POST"])
@login_required
def chat_send():
    data = request.get_json()
    user_message = data.get("message", "").strip()

    if not user_message:
        return jsonify({"error": "Message cannot be empty"}), 400

    # Pull recent history (last 10 messages) to give Gemini conversational context
    recent_history = (
        ChatMessage.query.filter_by(user_id=current_user.id)
        .order_by(ChatMessage.created_at.desc())
        .limit(10)
        .all()
    )
    recent_history.reverse()  # put back in chronological order
    history_payload = [{"sender": m.sender, "message": m.message} for m in recent_history]

    # Save the user's message first
    user_msg = ChatMessage(user_id=current_user.id, sender="user", message=user_message)
    db.session.add(user_msg)
    db.session.commit()

    # Get the AI's reply
    try:
        bot_reply = get_chat_response(user_message, chat_history=history_payload)
    except Exception as e:
        bot_reply = "Sorry, I'm having trouble responding right now. Please try again shortly."
        print(f"[Gemini error] {e}")  # logged server-side for debugging

    # Save the bot's reply
    bot_msg = ChatMessage(user_id=current_user.id, sender="bot", message=bot_reply)
    db.session.add(bot_msg)
    db.session.commit()

    return jsonify({"reply": bot_reply})
