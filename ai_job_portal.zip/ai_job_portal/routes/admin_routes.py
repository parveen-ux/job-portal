"""
routes/admin_routes.py
-------------------------
Admin panel to manage jobs and users.
A custom `admin_required` decorator guards every route here so
regular users get blocked even if they guess the URL.
"""

from functools import wraps
from flask import Blueprint, render_template, request, redirect, url_for, abort
from flask_login import login_required, current_user
from models import db
from models.job import Job
from models.user import User

admin_bp = Blueprint("admin", __name__)


def admin_required(f):
    """Decorator: only lets the request through if current_user.is_admin() is True."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin():
            abort(403)
        return f(*args, **kwargs)
    return decorated


@admin_bp.route("/admin")
@login_required
@admin_required
def admin_dashboard():
    job_count = Job.query.count()
    user_count = User.query.count()
    return render_template("admin/dashboard.html", job_count=job_count, user_count=user_count)


# ---------- MANAGE JOBS ----------

@admin_bp.route("/admin/jobs")
@login_required
@admin_required
def manage_jobs():
    jobs = Job.query.order_by(Job.created_at.desc()).all()
    return render_template("admin/manage_jobs.html", jobs=jobs)


@admin_bp.route("/admin/jobs/add", methods=["GET", "POST"])
@login_required
@admin_required
def add_job():
    if request.method == "POST":
        job = Job(
            title=request.form.get("title"),
            company=request.form.get("company"),
            location=request.form.get("location"),
            job_type=request.form.get("job_type"),
            required_skills=request.form.get("required_skills"),
            description=request.form.get("description"),
            hiring_process=request.form.get("hiring_process"),
            posted_by=current_user.id,
        )
        db.session.add(job)
        db.session.commit()
        return redirect(url_for("admin.manage_jobs"))

    return render_template("admin/add_job.html")


@admin_bp.route("/admin/jobs/<int:job_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_job(job_id):
    job = Job.query.get_or_404(job_id)
    db.session.delete(job)
    db.session.commit()
    return redirect(url_for("admin.manage_jobs"))


# ---------- MANAGE USERS ----------

@admin_bp.route("/admin/users")
@login_required
@admin_required
def manage_users():
    users = User.query.all()
    return render_template("admin/manage_users.html", users=users)


@admin_bp.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return redirect(url_for("admin.manage_users"))
