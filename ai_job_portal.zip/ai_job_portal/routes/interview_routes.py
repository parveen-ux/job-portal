"""
routes/interview_routes.py
-----------------------------
Handles Interview Questions (HR, Technical, Aptitude).
Shows questions already stored in the database, and also lets the
user generate fresh AI questions on demand for a specific topic/company.
"""

from flask import Blueprint, render_template, request
from flask_login import login_required
from models.interview import InterviewQuestion
from services.gemini_service import generate_interview_questions

interview_bp = Blueprint("interview", __name__)


@interview_bp.route("/interview")
@login_required
def questions():
    category = request.args.get("category", "HR")  # default tab
    stored_questions = InterviewQuestion.query.filter_by(category=category).all()
    return render_template("interview/questions.html", questions=stored_questions, category=category)


@interview_bp.route("/interview/generate", methods=["POST"])
@login_required
def generate():
    category = request.form.get("category", "Technical")
    topic = request.form.get("topic", "Software Engineering")

    try:
        ai_questions = generate_interview_questions(category, topic)
    except Exception as e:
        ai_questions = "Could not generate questions right now. Please try again."
        print(f"[Gemini error] {e}")

    stored_questions = InterviewQuestion.query.filter_by(category=category).all()
    return render_template(
        "interview/questions.html",
        questions=stored_questions,
        category=category,
        ai_questions=ai_questions,
        topic=topic,
    )
