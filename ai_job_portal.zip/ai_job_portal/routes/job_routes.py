"""
routes/job_routes.py
----------------------
Handles Job Search / Job Listings and Job Recommendations.
- /jobs            -> browse + search/filter all jobs
- /jobs/<id>        -> single job detail, including its hiring process
- /jobs/recommended -> AI-explained recommendations based on the user's skills
"""

from flask import Blueprint, render_template, request
from flask_login import login_required, current_user
from models.job import Job
from services.recommendation_service import recommend_jobs_for_user
from services.gemini_service import explain_job_match

job_bp = Blueprint("job", __name__)


@job_bp.route("/jobs")
@login_required
def job_list():
    # Simple search/filter via query params, e.g. /jobs?q=developer&location=remote
    query = request.args.get("q", "")
    location = request.args.get("location", "")

    jobs_query = Job.query
    if query:
        jobs_query = jobs_query.filter(Job.title.ilike(f"%{query}%"))
    if location:
        jobs_query = jobs_query.filter(Job.location.ilike(f"%{location}%"))

    jobs = jobs_query.order_by(Job.created_at.desc()).all()
    return render_template("jobs/list.html", jobs=jobs, query=query, location=location)


@job_bp.route("/jobs/<int:job_id>")
@login_required
def job_detail(job_id):
    job = Job.query.get_or_404(job_id)
    return render_template("jobs/detail.html", job=job)


@job_bp.route("/jobs/recommended")
@login_required
def recommended_jobs():
    # Step 1: fast local skill-matching (no AI call needed for scoring)
    matches = recommend_jobs_for_user(current_user, limit=5)

    # Step 2: ask Gemini for a short human-friendly explanation per match
    results = []
    for job, score in matches:
        try:
            explanation = explain_job_match(current_user.skill_list(), job)
        except Exception as e:
            explanation = "This job matches several of your listed skills."
            print(f"[Gemini error] {e}")
        results.append({"job": job, "score": score, "explanation": explanation})

    return render_template("jobs/recommended.html", results=results)
