"""
routes/auth_routes.py
----------------------
Handles User Login and Signup.
Uses Flask-Bcrypt to hash passwords (never store plain text passwords)
and Flask-Login to manage the logged-in session.
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required
from models import db
from models.user import User
from extensions import bcrypt  # shared Bcrypt instance, see extensions.py

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        name = request.form.get("name")
        email = request.form.get("email")
        password = request.form.get("password")
        skills = request.form.get("skills", "")  # comma-separated skills entered at signup

        # Prevent duplicate accounts
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("An account with this email already exists.", "error")
            return redirect(url_for("auth.signup"))

        # Hash the password before saving — never store raw passwords
        hashed_pw = bcrypt.generate_password_hash(password).decode("utf-8")

        new_user = User(name=name, email=email, password_hash=hashed_pw, skills=skills)
        db.session.add(new_user)
        db.session.commit()

        flash("Account created! Please log in.", "success")
        return redirect(url_for("auth.login"))

    return render_template("auth/signup.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        user = User.query.filter_by(email=email).first()

        # Check the user exists AND the password matches the stored hash
        if user and bcrypt.check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for("dashboard.dashboard"))

        flash("Invalid email or password.", "error")
        return redirect(url_for("auth.login"))

    return render_template("auth/login.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("auth.login"))
