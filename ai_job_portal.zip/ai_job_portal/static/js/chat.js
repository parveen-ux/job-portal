/*
 chat.js
 -------
 Handles the front-end behavior of the AI chat interface:
 - Grabs the message the user types
 - Immediately shows it in the chat window (no page reload)
 - Sends it to the Flask backend via fetch()
 - Displays the AI's reply once it comes back
*/

const chatForm = document.getElementById("chat-form");
const chatInput = document.getElementById("chat-input");
const chatWindow = document.getElementById("chat-window");
const typingIndicator = document.getElementById("typing-indicator");

// Adds a single message bubble to the chat window
function appendBubble(text, sender) {
    const bubble = document.createElement("div");
    bubble.classList.add("chat-bubble", sender === "user" ? "bubble-user" : "bubble-bot");
    bubble.textContent = text;
    chatWindow.appendChild(bubble);
    chatWindow.scrollTop = chatWindow.scrollHeight; // auto-scroll to latest message
}

chatForm.addEventListener("submit", async function (e) {
    e.preventDefault(); // stop normal form submission (which would reload the page)

    const message = chatInput.value.trim();
    if (!message) return;

    appendBubble(message, "user");
    chatInput.value = "";
    typingIndicator.style.display = "block";

    try {
        const response = await fetch("/chat/send", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: message }),
        });

        const data = await response.json();
        typingIndicator.style.display = "none";

        if (data.reply) {
            appendBubble(data.reply, "bot");
        } else {
            appendBubble("Something went wrong. Please try again.", "bot");
        }
    } catch (err) {
        typingIndicator.style.display = "none";
        appendBubble("Network error — please check your connection.", "bot");
        console.error(err);
    }
});
