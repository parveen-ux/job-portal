"""
app.py
------
The application factory / entry point.
Run this file to start the server: `python app.py`

Responsibilities:
1. Create the Flask app and load config
2. Initialize extensions (SQLAlchemy, Bcrypt, LoginManager)
3. Register all route blueprints
4. Create database tables if they don't exist
"""

from flask import Flask
from config import Config
from models import db
from models.user import User
from extensions import bcrypt, login_manager

# Import all blueprints (each file in routes/ defines one feature area)
from routes.auth_routes import auth_bp
from routes.chat_routes import chat_bp
from routes.job_routes import job_bp
from routes.resume_routes import resume_bp
from routes.interview_routes import interview_bp
from routes.coding_routes import coding_bp
from routes.dashboard_routes import dashboard_bp
from routes.admin_routes import admin_bp


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # ---- Initialize extensions with this app instance ----
    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)

    # Tells Flask-Login how to load a user from the ID stored in the session cookie
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # ---- Register blueprints (each adds its own set of URL routes) ----
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(chat_bp)
    app.register_blueprint(job_bp)
    app.register_blueprint(resume_bp)
    app.register_blueprint(interview_bp)
    app.register_blueprint(coding_bp)
    app.register_blueprint(admin_bp)

    # ---- Create tables automatically if they don't already exist ----
    # (You can also just run database/schema.sql manually instead.)
    with app.app_context():
        db.create_all()

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, port=5000)
