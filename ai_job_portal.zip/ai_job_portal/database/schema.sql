-- schema.sql
-- ----------
-- Run this once to create the database and tables manually, OR
-- let SQLAlchemy auto-create tables via `db.create_all()` in app.py.
-- Keeping this file lets you (or a DBA) inspect the exact structure being used.

CREATE DATABASE IF NOT EXISTS ai_job_portal;
USE ai_job_portal;

-- ============ USERS ============
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',   -- distinguishes normal users from admin panel access
    skills TEXT,                                  -- comma-separated skills, used for job recommendations
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============ JOBS ============
CREATE TABLE IF NOT EXISTS jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    company VARCHAR(150) NOT NULL,
    location VARCHAR(100),
    job_type ENUM('Full-time', 'Part-time', 'Internship', 'Remote') DEFAULT 'Full-time',
    required_skills TEXT,          -- comma-separated skills required for the job (used for matching)
    description TEXT,
    hiring_process TEXT,           -- describes company-wise hiring rounds
    posted_by INT,                 -- admin user id who posted it
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (posted_by) REFERENCES users(id)
);

-- ============ CHAT HISTORY (career guidance chatbot) ============
CREATE TABLE IF NOT EXISTS chat_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    sender ENUM('user', 'bot') NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ============ RESUMES ============
CREATE TABLE IF NOT EXISTS resumes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    full_name VARCHAR(100),
    email VARCHAR(150),
    phone VARCHAR(20),
    summary TEXT,
    education TEXT,
    experience TEXT,
    skills TEXT,
    projects TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ============ INTERVIEW QUESTIONS ============
CREATE TABLE IF NOT EXISTS interview_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category ENUM('HR', 'Technical', 'Aptitude') NOT NULL,
    question TEXT NOT NULL,
    answer TEXT,               -- suggested answer / explanation
    company VARCHAR(150),      -- optional: tie a question to a specific company
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============ CODING PROBLEMS ============
CREATE TABLE IF NOT EXISTS coding_problems (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    difficulty ENUM('Easy', 'Medium', 'Hard') DEFAULT 'Easy',
    description TEXT,
    sample_input TEXT,
    sample_output TEXT,
    topic VARCHAR(100)          -- e.g. "Arrays", "Strings", "DP"
);
