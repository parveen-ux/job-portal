"""
seed_data.py
------------
Run this ONCE after setting up the database to populate it with
sample jobs, interview questions, coding problems, and an admin account,
so the app isn't empty when you first try it.

Usage:  python seed_data.py
"""

from app import create_app
from models import db
from models.user import User
from models.job import Job
from models.interview import InterviewQuestion
from models.coding import CodingProblem
from extensions import bcrypt

app = create_app()

with app.app_context():

    # ---- Create an admin account (only if one doesn't already exist) ----
    if not User.query.filter_by(email="admin@jobportal.com").first():
        admin = User(
            name="Admin",
            email="admin@jobportal.com",
            password_hash=bcrypt.generate_password_hash("admin123").decode("utf-8"),
            role="admin",
        )
        db.session.add(admin)

    # ---- Sample jobs ----
    if Job.query.count() == 0:
        sample_jobs = [
            Job(
                title="Junior Python Developer",
                company="TechNova",
                location="Bangalore, India",
                job_type="Full-time",
                required_skills="python,flask,sql,git",
                description="Work on backend features for our SaaS product using Flask and MySQL.",
                hiring_process="Round 1: Online coding test\nRound 2: Technical interview\nRound 3: HR interview",
            ),
            Job(
                title="Frontend Developer",
                company="PixelWorks",
                location="Remote",
                job_type="Remote",
                required_skills="javascript,html,css,react",
                description="Build responsive UI components for our design system.",
                hiring_process="Round 1: Portfolio review\nRound 2: Live coding\nRound 3: Team fit interview",
            ),
            Job(
                title="Data Analyst Intern",
                company="DataSpring",
                location="Hyderabad, India",
                job_type="Internship",
                required_skills="python,sql,excel",
                description="Assist the analytics team with dashboards and reporting.",
                hiring_process="Round 1: Aptitude test\nRound 2: Case study\nRound 3: Manager interview",
            ),
        ]
        db.session.add_all(sample_jobs)

    # ---- Sample interview questions ----
    if InterviewQuestion.query.count() == 0:
        sample_questions = [
            InterviewQuestion(category="HR", question="Tell me about yourself.",
                               answer="Keep it structured: current role, key achievement, why you're excited about this role."),
            InterviewQuestion(category="HR", question="Why do you want to work here?",
                               answer="Connect your skills/values to the company's mission and a specific product/team."),
            InterviewQuestion(category="Technical", question="What is the difference between a list and a tuple in Python?",
                               answer="Lists are mutable; tuples are immutable. Tuples are slightly faster and hashable."),
            InterviewQuestion(category="Technical", question="Explain how a JOIN works in SQL.",
                               answer="A JOIN combines rows from two tables based on a related column, e.g. INNER JOIN returns only matching rows."),
            InterviewQuestion(category="Aptitude", question="If a train travels 60km in 45 minutes, what is its speed in km/h?",
                               answer="80 km/h (60 / 0.75 hours)."),
        ]
        db.session.add_all(sample_questions)

    # ---- Sample coding problems ----
    if CodingProblem.query.count() == 0:
        sample_problems = [
            CodingProblem(
                title="Two Sum",
                difficulty="Easy",
                topic="Arrays",
                description="Given an array of integers and a target, return indices of the two numbers that add up to the target.",
                sample_input="nums = [2,7,11,15], target = 9",
                sample_output="[0,1]",
            ),
            CodingProblem(
                title="Reverse a String",
                difficulty="Easy",
                topic="Strings",
                description="Write a function that reverses a string in place.",
                sample_input='"hello"',
                sample_output='"olleh"',
            ),
            CodingProblem(
                title="Longest Common Subsequence",
                difficulty="Medium",
                topic="Dynamic Programming",
                description="Find the length of the longest common subsequence between two strings.",
                sample_input='"abcde", "ace"',
                sample_output="3",
            ),
        ]
        db.session.add_all(sample_problems)

    db.session.commit()
    print("✅ Sample data seeded successfully!")
    print("Admin login -> email: admin@jobportal.com | password: admin123")
