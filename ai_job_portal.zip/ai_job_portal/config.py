"""
config.py
---------
Central place for all app configuration.
Reads values from the .env file so secrets are never hard-coded in the source.
"""

import os
from dotenv import load_dotenv

# Load variables from the .env file into the environment
load_dotenv()


class Config:
    # Used by Flask to sign session cookies and CSRF tokens
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key")

    # Build the MySQL connection string for SQLAlchemy using PyMySQL driver
    DB_HOST = os.getenv("DB_HOST", "localhost")
    DB_PORT = os.getenv("DB_PORT", "3306")
    DB_USER = os.getenv("DB_USER", "root")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "")
    DB_NAME = os.getenv("DB_NAME", "ai_job_portal")

    SQLALCHEMY_DATABASE_URI = (
        f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False  # disables an unneeded SQLAlchemy feature that wastes memory

    # Gemini API key used by services/gemini_service.py
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
