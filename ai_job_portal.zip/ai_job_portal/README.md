# AI Job Portal

A full-stack job portal with an AI-powered chat interface, built with
Flask, MySQL, and the Google Gemini API.

## Folder Structure

```
ai_job_portal/
├── app.py                   # Main entry point — creates and runs the Flask app
├── config.py                 # Loads settings (DB, secret key, Gemini API key) from .env
├── extensions.py              # Shared Bcrypt + LoginManager instances (avoids circular imports)
├── seed_data.py               # Populates sample jobs/questions/problems + an admin account
├── requirements.txt            # Python dependencies
├── .env.example                # Template for your local secrets file
│
├── database/
│   └── schema.sql              # Raw MySQL schema (optional manual alternative to db.create_all())
│
├── models/                     # SQLAlchemy models = Python classes representing DB tables
│   ├── __init__.py             # Creates the shared `db` object
│   ├── user.py                 # Users table (auth, skills, role)
│   ├── job.py                  # Job listings table
│   ├── chat.py                 # Chat history table (AI chatbot)
│   ├── resume.py                # Resumes created via Resume Builder
│   ├── interview.py             # Interview questions (HR/Technical/Aptitude)
│   └── coding.py                # Coding practice problems
│
├── services/                    # Business logic that isn't just "handle an HTTP request"
│   ├── gemini_service.py         # All Gemini API calls live here (chat, resume analysis, etc.)
│   └── recommendation_service.py # Skill-matching logic for job recommendations
│
├── routes/                       # Flask blueprints — one file per feature area
│   ├── auth_routes.py             # Login / signup / logout
│   ├── chat_routes.py             # AI career guidance chatbot
│   ├── job_routes.py              # Job search, listings, recommendations
│   ├── resume_routes.py           # Resume builder + analyzer
│   ├── interview_routes.py        # Interview question bank + AI generation
│   ├── coding_routes.py           # Coding practice problems
│   ├── dashboard_routes.py        # Landing page + user dashboard
│   └── admin_routes.py            # Admin panel (manage jobs/users)
│
├── templates/                     # Jinja2 HTML templates (organized to mirror routes/)
│   ├── base.html                   # Shared navbar/layout
│   ├── index.html                  # Public landing page
│   ├── dashboard.html               # User dashboard
│   ├── chat.html                    # AI chat interface
│   ├── auth/ (login.html, signup.html)
│   ├── jobs/ (list.html, detail.html, recommended.html)
│   ├── resume/ (builder.html, preview.html, pdf_template.html, analyzer.html)
│   ├── interview/ (questions.html)
│   ├── coding/ (practice.html, detail.html)
│   └── admin/ (dashboard.html, manage_jobs.html, add_job.html, manage_users.html)
│
└── static/
    ├── css/style.css              # All site styling
    └── js/chat.js                  # Chat interface front-end logic
```

## Setup Instructions

### 1. Install dependencies
```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Set up MySQL
Create the database (or let the app do it automatically):
```bash
mysql -u root -p < database/schema.sql
```

### 3. Configure environment variables
```bash
cp .env.example .env
# then edit .env and fill in your DB password and Gemini API key
```
Get a free Gemini API key at: https://aistudio.google.com/app/apikey

### 4. Run the app
```bash
python app.py
```
This automatically creates any missing tables via `db.create_all()`.

### 5. (Optional) Seed sample data
```bash
python seed_data.py
```
This creates sample jobs, interview questions, coding problems, and an
admin account:
- **Email:** admin@jobportal.com
- **Password:** admin123

### 6. Open the app
Visit **http://localhost:5000** in your browser.

## Build Order (how this project was structured)

1. **Backend + Chat Interface** — Flask app skeleton, DB models, auth
   (login/signup), and the AI chatbot (chat.html + chat.js + Gemini
   service) were built first, since the chat interface was the
   centerpiece of the request.
2. **Job Search & Recommendations** — job listings, search/filter,
   company hiring-process pages, and skill-based recommendations
   (with Gemini generating a friendly explanation of each match).
3. **Resume Builder & Analyzer** — form-based resume creation with
   PDF export, plus a separate Gemini-powered resume feedback tool.
4. **Interview Prep & Coding Practice** — categorized question bank
   with on-demand AI question generation, and a coding-problem
   browser for self-practice.
5. **Dashboard & Admin Panel** — a personalized user dashboard, and
   an admin-only area to manage job postings and users.

## Notes & Known Limitations

- **Coding Practice** shows problems and a free-text area for
  self-review; it does **not** execute submitted code. Running
  arbitrary user code safely requires an isolated sandbox/judge
  service, which is a separate infrastructure concern.
- **Passwords** are hashed with Bcrypt — never stored in plain text.
- **Gemini API errors** are caught everywhere they're used, so the
  site degrades gracefully (shows a friendly message) instead of
  crashing if the API is down or the key is missing/invalid.
- This is an MVP: pagination, rate limiting, email verification, and
  more polished error pages would be the next additions for
  production use.
