"""
services/gemini_service.py
---------------------------
Single place that talks to the Google Gemini API.
Every AI feature (chatbot, resume analyzer, interview question
generation, job-recommendation explanations) calls functions from
this file instead of calling the Gemini SDK directly. This keeps API
key handling and prompt formatting in one spot.
"""

import google.generativeai as genai
from config import Config

# Configure the SDK once with our API key from .env
genai.configure(api_key=Config.GEMINI_API_KEY)

# Using gemini-1.5-flash: fast + cheap, good enough for chat/analysis tasks.
MODEL_NAME = "gemini-1.5-flash"


def _get_model(system_instruction=None):
    """Creates a GenerativeModel instance, optionally with a system prompt
    that steers its behavior (e.g. 'You are a career advisor')."""
    return genai.GenerativeModel(
        model_name=MODEL_NAME,
        system_instruction=system_instruction,
    )


def get_chat_response(user_message, chat_history=None):
    """
    Used by the AI Career Guidance Chatbot.
    `chat_history` is a list of {"role": "user"/"model", "text": "..."} dicts
    so the model has conversational context, not just the latest message.
    """
    system_prompt = (
        "You are an expert career guidance counselor on a job portal website. "
        "Give concise, practical, encouraging advice about careers, skills to learn, "
        "job searching, interview prep, and resumes. Keep answers under 200 words "
        "unless the user asks for something detailed."
    )
    model = _get_model(system_instruction=system_prompt)

    # Convert our simple history format into Gemini's expected chat format
    history = []
    if chat_history:
        for turn in chat_history:
            role = "user" if turn["sender"] == "user" else "model"
            history.append({"role": role, "parts": [turn["message"]]})

    chat = model.start_chat(history=history)
    response = chat.send_message(user_message)
    return response.text


def analyze_resume(resume_text, target_job_title=None):
    """
    Used by the Resume Analyzer feature.
    Sends resume text to Gemini and asks for structured feedback:
    strengths, weaknesses, missing keywords, and an overall score.
    """
    job_context = f" for a '{target_job_title}' role" if target_job_title else ""
    prompt = f"""
Analyze the following resume{job_context}. Respond in this exact structure:

SCORE: <a number 0-100>
STRENGTHS:
- ...
WEAKNESSES:
- ...
MISSING_KEYWORDS:
- ...
SUGGESTIONS:
- ...

Resume:
\"\"\"
{resume_text}
\"\"\"
"""
    model = _get_model()
    response = model.generate_content(prompt)
    return response.text


def generate_interview_questions(category, topic_or_company, count=5):
    """
    Used by the Interview Questions feature to generate fresh questions
    on demand (in addition to the ones stored in the database).
    `category` is one of "HR", "Technical", "Aptitude".
    """
    prompt = (
        f"Generate {count} {category} interview questions related to "
        f"'{topic_or_company}'. For each, also give a short model answer. "
        f"Format as:\n1. Question\nAnswer: ...\n2. Question\nAnswer: ...\n"
    )
    model = _get_model()
    response = model.generate_content(prompt)
    return response.text


def explain_job_match(user_skills, job):
    """
    Used by Job Recommendations to generate a short, human-readable
    explanation of why a job was recommended to this user.
    """
    prompt = (
        f"A user has these skills: {', '.join(user_skills)}.\n"
        f"A job posting requires: {job.required_skills}.\n"
        f"Job title: {job.title} at {job.company}.\n"
        "In 1-2 short sentences, explain why this job is a good match for the user, "
        "and mention one skill they could learn to be an even stronger fit."
    )
    model = _get_model()
    response = model.generate_content(prompt)
    return response.text
