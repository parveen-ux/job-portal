"""
services/recommendation_service.py
------------------------------------
Handles the "Job recommendations based on skills" feature.
The matching itself is plain Python (fast, free, deterministic) —
Gemini is only used afterward to generate a friendly explanation
for the top matches (see gemini_service.explain_job_match).
"""

from models.job import Job


def recommend_jobs_for_user(user, limit=5):
    """
    Scores every job by how many of its required_skills overlap with
    the user's skills, then returns the top-scoring jobs.
    Returns a list of (job, match_score_percent) tuples.
    """
    user_skills = set(user.skill_list())
    if not user_skills:
        return []

    all_jobs = Job.query.all()
    scored = []

    for job in all_jobs:
        job_skills = set(job.required_skill_list())
        if not job_skills:
            continue

        overlap = user_skills & job_skills
        if not overlap:
            continue

        match_score = round(len(overlap) / len(job_skills) * 100)
        scored.append((job, match_score))

    # Highest match percentage first
    scored.sort(key=lambda pair: pair[1], reverse=True)
    return scored[:limit]
