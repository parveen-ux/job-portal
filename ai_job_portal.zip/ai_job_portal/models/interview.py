"""
models/interview.py
--------------------
Stores interview questions used by the "Interview Questions" feature,
categorized as HR, Technical, or Aptitude, and optionally tied to a
specific company.
"""

from models import db


class InterviewQuestion(db.Model):
    __tablename__ = "interview_questions"

    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(20), nullable=False)  # "HR" | "Technical" | "Aptitude"
    question = db.Column(db.Text, nullable=False)
    answer = db.Column(db.Text)
    company = db.Column(db.String(150))
    created_at = db.Column(db.DateTime, server_default=db.func.now())
