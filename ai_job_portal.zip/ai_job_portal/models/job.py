"""
models/job.py
-------------
Defines the Job table: every job listing posted on the portal,
including the company's hiring process description used on the
"Company-wise hiring process" feature.
"""

from models import db


class Job(db.Model):
    __tablename__ = "jobs"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    company = db.Column(db.String(150), nullable=False)
    location = db.Column(db.String(100))
    job_type = db.Column(db.String(20), default="Full-time")
    required_skills = db.Column(db.Text)     # comma-separated, matched against user.skills
    description = db.Column(db.Text)
    hiring_process = db.Column(db.Text)      # e.g. "Round 1: Online Test\nRound 2: Technical Interview..."
    posted_by = db.Column(db.Integer, db.ForeignKey("users.id"))
    created_at = db.Column(db.DateTime, server_default=db.func.now())

    def required_skill_list(self):
        if not self.required_skills:
            return []
        return [s.strip().lower() for s in self.required_skills.split(",") if s.strip()]
