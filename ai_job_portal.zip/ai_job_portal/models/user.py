"""
models/user.py
--------------
Defines the User table. Uses Flask-Login's UserMixin so this class
automatically gets the properties Flask-Login needs (is_authenticated,
get_id, etc.) without us writing them by hand.
"""

from flask_login import UserMixin
from models import db


class User(db.Model, UserMixin):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default="user")   # "user" or "admin"
    skills = db.Column(db.Text)                        # comma-separated, e.g. "Python,Flask,SQL"
    created_at = db.Column(db.DateTime, server_default=db.func.now())

    def is_admin(self):
        """Small helper used in templates/routes to gate admin-only pages."""
        return self.role == "admin"

    def skill_list(self):
        """Returns the user's skills as a clean Python list instead of a raw string."""
        if not self.skills:
            return []
        return [s.strip().lower() for s in self.skills.split(",") if s.strip()]
