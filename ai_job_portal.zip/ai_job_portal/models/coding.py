"""
models/coding.py
-----------------
Stores coding-practice problems shown on the "Coding Practice" page.
Note: this MVP displays problems and accepts free-text answers for
self-review; it does not include a full online code-execution sandbox
(that would need a separate isolated execution service for security).
"""

from models import db


class CodingProblem(db.Model):
    __tablename__ = "coding_problems"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    difficulty = db.Column(db.String(10), default="Easy")  # Easy | Medium | Hard
    description = db.Column(db.Text)
    sample_input = db.Column(db.Text)
    sample_output = db.Column(db.Text)
    topic = db.Column(db.String(100))
