"""
models/resume.py
-----------------
Stores resumes created through the Resume Builder feature.
Keeping the fields separate (instead of one big text blob) makes it
possible to re-render the resume in different templates/styles later.
"""

from models import db


class Resume(db.Model):
    __tablename__ = "resumes"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    full_name = db.Column(db.String(100))
    email = db.Column(db.String(150))
    phone = db.Column(db.String(20))
    summary = db.Column(db.Text)
    education = db.Column(db.Text)
    experience = db.Column(db.Text)
    skills = db.Column(db.Text)
    projects = db.Column(db.Text)
    created_at = db.Column(db.DateTime, server_default=db.func.now())
