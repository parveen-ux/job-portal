"""
models/chat.py
--------------
Stores every message exchanged with the AI career-guidance chatbot,
so a user's chat history persists between visits/logins.
"""

from models import db


class ChatMessage(db.Model):
    __tablename__ = "chat_history"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    sender = db.Column(db.String(10), nullable=False)   # "user" or "bot"
    message = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())
