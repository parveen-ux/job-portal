"""
models/__init__.py
-------------------
Creates the single shared SQLAlchemy `db` object.
Every model file imports `db` from here so they all share the same
database connection/session instead of creating duplicates.
"""

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
